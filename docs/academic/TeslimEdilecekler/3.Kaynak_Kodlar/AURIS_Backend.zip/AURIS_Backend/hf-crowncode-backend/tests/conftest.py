"""Shared test fixtures for CrownCode backend tests."""

from __future__ import annotations

import pytest
from starlette.testclient import TestClient

from app.main import app


@pytest.fixture()
def client():
    """Create a test client for the FastAPI application."""
    with TestClient(app) as c:
        yield c
