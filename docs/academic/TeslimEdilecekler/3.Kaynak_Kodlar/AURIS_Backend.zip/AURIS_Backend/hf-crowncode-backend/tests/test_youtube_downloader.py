"""Tests for YouTube downloader error handling and auth configuration."""

from __future__ import annotations

import asyncio

from app.services.youtube_analysis import YouTubeAnalysisService
from app.services.youtube_downloader import (
    DownloadAttemptFailure,
    DownloadAttemptResult,
    YouTubeDownloadError,
    YouTubeDownloader,
)


_BOT_CHECK_MESSAGE = (
    "Sign in to confirm you're not a bot. "
    "Use --cookies-from-browser or --cookies for the authentication."
)


def test_base_options_supports_browser_cookies_from_env(tmp_path, monkeypatch) -> None:
    monkeypatch.delenv("YOUTUBE_COOKIES_FILE", raising=False)
    monkeypatch.delenv("YOUTUBE_COOKIES_BASE64", raising=False)
    monkeypatch.setenv("YOUTUBE_COOKIES_FROM_BROWSER", "edge:Default")

    downloader = YouTubeDownloader(output_dir=tmp_path)

    opts = downloader._base_options("tDN-u5gporg")

    assert opts["cookiesfrombrowser"] == ("edge", "Default", None, None)


def test_download_raises_auth_required_for_bot_check(tmp_path, monkeypatch) -> None:
    failures = [DownloadAttemptFailure(client_label="android+web", message=_BOT_CHECK_MESSAGE)]

    def fake_with_ffmpeg(self, url: str, video_id: str) -> DownloadAttemptResult:
        return DownloadAttemptResult(info=None, failures=failures)

    def fake_without_ffmpeg(self, url: str, video_id: str) -> DownloadAttemptResult:
        return DownloadAttemptResult(info=None, failures=failures)

    monkeypatch.setattr(YouTubeDownloader, "_download_with_ffmpeg", fake_with_ffmpeg)
    monkeypatch.setattr(YouTubeDownloader, "_download_without_ffmpeg", fake_without_ffmpeg)

    downloader = YouTubeDownloader(output_dir=tmp_path)

    try:
        downloader.download("https://www.youtube.com/watch?v=tDN-u5gporg", "tDN-u5gporg")
        raise AssertionError("Expected YouTubeDownloadError")
    except YouTubeDownloadError as exc:
        assert exc.error_code == "youtube_authentication_required"
        assert "youtube_authentication_required" in exc.warnings


def test_download_falls_back_without_ffmpeg_and_keeps_real_warning(tmp_path, monkeypatch) -> None:
    ffmpeg_failure = DownloadAttemptFailure(
        client_label="android+web",
        message=(
            "Postprocessing: ffprobe and ffmpeg not found. "
            "Please install or provide the path using --ffmpeg-location"
        ),
    )

    def fake_with_ffmpeg(self, url: str, video_id: str) -> DownloadAttemptResult:
        return DownloadAttemptResult(info=None, failures=[ffmpeg_failure])

    def fake_without_ffmpeg(self, url: str, video_id: str) -> DownloadAttemptResult:
        output_file = self.output_dir / f"{video_id}.m4a"
        output_file.write_bytes(b"fake audio")
        return DownloadAttemptResult(
            info={"ext": "m4a", "title": "Example Title", "duration": 12.5},
            failures=[],
        )

    monkeypatch.setattr(YouTubeDownloader, "_download_with_ffmpeg", fake_with_ffmpeg)
    monkeypatch.setattr(YouTubeDownloader, "_download_without_ffmpeg", fake_without_ffmpeg)

    downloader = YouTubeDownloader(output_dir=tmp_path)
    result = downloader.download("https://www.youtube.com/watch?v=tDN-u5gporg", "tDN-u5gporg")

    assert result.audio_format == "m4a"
    assert result.warnings == ["ffmpeg_unavailable"]


def test_youtube_analysis_surfaces_auth_required_error(monkeypatch) -> None:
    def fake_download(self, url: str, video_id: str):
        raise YouTubeDownloadError(
            error_code="youtube_authentication_required",
            message=_BOT_CHECK_MESSAGE,
            warnings=["youtube_authentication_required"],
        )

    monkeypatch.setattr(YouTubeDownloader, "download", fake_download)

    response = asyncio.run(
        YouTubeAnalysisService().analyze(
            "https://www.youtube.com/watch?v=tDN-u5gporg",
            include_raw=True,
        )
    )

    assert response.status == "partial"
    assert "youtube_authentication_required" in response.errors
    assert "youtube_analysis_failed" in response.errors
    assert "youtube_authentication_required" in response.warnings
    assert response.music_ai.error == "youtube_authentication_required"
    assert response.ses_analizi.error == "youtube_authentication_required"
