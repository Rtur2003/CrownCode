"""Tests for YouTube analysis endpoint."""

from __future__ import annotations

from fastapi.testclient import TestClient


def test_youtube_analyze_rejects_invalid_url(client: TestClient) -> None:
    """YouTube analyze should reject a non-YouTube URL."""
    response = client.post(
        "/api/youtube/analyze",
        json={"url": "https://example.com/not-youtube"},
    )
    assert response.status_code in (400, 422)


def test_youtube_analyze_rejects_empty_url(client: TestClient) -> None:
    """YouTube analyze should reject an empty URL."""
    response = client.post(
        "/api/youtube/analyze",
        json={"url": ""},
    )
    assert response.status_code in (400, 422)


def test_youtube_analyze_rejects_missing_body(client: TestClient) -> None:
    """YouTube analyze should reject a request with no body."""
    response = client.post("/api/youtube/analyze")
    assert response.status_code == 422
