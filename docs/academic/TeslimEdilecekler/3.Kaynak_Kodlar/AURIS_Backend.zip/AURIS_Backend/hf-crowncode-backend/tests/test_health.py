"""Tests for health check and root endpoints."""

from __future__ import annotations

from fastapi.testclient import TestClient


def test_root_returns_api_info(client: TestClient) -> None:
    """Root endpoint should return API name, version, and status."""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "CrownCode Backend API"
    assert data["status"] == "running"
    assert "version" in data


def test_health_endpoint(client: TestClient) -> None:
    """Health endpoint should return ok status with services info."""
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert "services" in data
