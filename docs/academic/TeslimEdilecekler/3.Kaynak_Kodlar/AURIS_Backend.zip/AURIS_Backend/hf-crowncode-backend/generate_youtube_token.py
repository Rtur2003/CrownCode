"""
YouTube OAuth Token Generator for Crown Commend
Bu script'i bir kez çalıştırıp token.json oluşturacaksın.

Kullanım:
1. client_secret_XXXXX.json dosyasını bu klasöre kopyala
2. Dosya adını 'client_secret.json' olarak değiştir
3. Bu script'i çalıştır: python generate_youtube_token.py
4. Tarayıcıda Google hesabınla giriş yap
5. token.json dosyası oluşacak
6. token.json içeriğini COMMEND_TOKEN_JSON environment variable'a koy
"""

import os
import json
from google_auth_oauthlib.flow import InstalledAppFlow
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request

# YouTube yorum yazma için gerekli scope
SCOPES = ['https://www.googleapis.com/auth/youtube.force-ssl']

def main():
    creds = None

    # Mevcut token varsa kontrol et
    if os.path.exists('token.json'):
        print("Mevcut token.json bulundu, kontrol ediliyor...")
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)

    # Token yoksa veya geçersizse yeni token al
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            print("Token expired, refreshing...")
            creds.refresh(Request())
        else:
            # client_secret.json dosyasını kontrol et
            if not os.path.exists('client_secret.json'):
                print("\n" + "="*60)
                print("HATA: client_secret.json dosyası bulunamadı!")
                print("="*60)
                print("\nYapman gerekenler:")
                print("1. Google Cloud Console'dan indirdiğin")
                print("   client_secret_XXXXX.json dosyasını bu klasöre kopyala")
                print("2. Dosya adını 'client_secret.json' olarak değiştir")
                print("3. Bu script'i tekrar çalıştır")
                print("="*60 + "\n")
                return

            print("\nTarayıcı açılacak, Google hesabınla giriş yap...")
            print("(Test kullanıcısı olarak eklediğin hesapla giriş yapmalısın)\n")

            flow = InstalledAppFlow.from_client_secrets_file(
                'client_secret.json',
                SCOPES
            )
            creds = flow.run_local_server(port=8080)

        # Token'ı kaydet
        with open('token.json', 'w') as token_file:
            token_file.write(creds.to_json())
        print("\n✓ token.json başarıyla oluşturuldu!")

    # Token içeriğini göster
    print("\n" + "="*60)
    print("COMMEND_TOKEN_JSON için kullanacağın değer:")
    print("="*60)

    with open('token.json', 'r') as f:
        token_data = json.load(f)

    # Tek satır JSON olarak yazdır (environment variable için)
    token_json_str = json.dumps(token_data)
    print("\n" + token_json_str)

    print("\n" + "="*60)
    print("Yukarıdaki JSON'u kopyala ve COMMEND_TOKEN_JSON")
    print("environment variable olarak ayarla.")
    print("="*60 + "\n")

    # Test: Token çalışıyor mu?
    print("Token test ediliyor...")
    try:
        from googleapiclient.discovery import build
        youtube = build('youtube', 'v3', credentials=creds)

        # Kendi kanalını çek
        request = youtube.channels().list(
            part="snippet",
            mine=True
        )
        response = request.execute()

        if response.get('items'):
            channel_name = response['items'][0]['snippet']['title']
            print(f"✓ Token çalışıyor! Bağlı kanal: {channel_name}")
        else:
            print("⚠ Token çalışıyor ama YouTube kanalı bulunamadı.")
            print("  YouTube'da bir kanal oluşturduğundan emin ol.")
    except Exception as e:
        print(f"⚠ Token test hatası: {e}")
        print("  Ama token.json oluşturuldu, deneyebilirsin.")

if __name__ == '__main__':
    main()
