"""
One-time script: upload all AURIS model artifacts to HuggingFace Hub.

Usage:
    python upload_models_to_hub.py

Requires:
    pip install huggingface-hub
    huggingface-cli login   (or set HF_TOKEN env var)

Creates / updates: Rthur2003/auris-models  (model repo, public)
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

REPO_ID    = "Rthur2003/auris-models"
MODELS_DIR = Path(__file__).parent / "models"
HF_TOKEN   = os.getenv("HF_TOKEN") or os.getenv("HUGGING_FACE_HUB_TOKEN")

FILES_TO_UPLOAD = [
    # Core classifier
    "auris_classifier_v1.pkl",
    "feature_scaler_v1.pkl",
    "feature_columns_v1.json",
    "feature_stats_v1.json",
    "training_results.json",
    "deep_learning_results.json",
    # ML models
    "model_logistic_regression.pkl",
    "model_random_forest.pkl",
    "model_gradient_boosting.pkl",
    "model_svm_rbf.pkl",
    "model_mlp_neural_network.pkl",
    "model_xgboost.pkl",
    "model_lightgbm.pkl",
    # DL models
    "model_dl_deep_mlp_512_256_128_64.pkl",
    "model_dl_1d_cnn.pkl",
    "model_dl_residual_mlp_3_blocks.pkl",
    "model_dl_attention_mlp.pkl",
    # wav2vec2 transformer
    "wav2vec2_auris_v1.pt",
]


def main() -> None:
    try:
        from huggingface_hub import HfApi, create_repo
    except ImportError:
        print("ERROR: pip install huggingface-hub")
        sys.exit(1)

    api = HfApi(token=HF_TOKEN)

    # Create repo if it doesn't exist
    try:
        create_repo(REPO_ID, repo_type="model", exist_ok=True, token=HF_TOKEN)
        print(f"Repo ready: https://huggingface.co/{REPO_ID}")
    except Exception as e:
        print(f"WARNING: could not create repo: {e}")

    errors: list[str] = []
    for filename in FILES_TO_UPLOAD:
        src = MODELS_DIR / filename
        if not src.exists():
            print(f"  SKIP  {filename} (not found locally)")
            continue

        size_mb = src.stat().st_size / 1024 / 1024
        print(f"  UP    {filename} ({size_mb:.1f} MB) ...", end=" ", flush=True)
        try:
            api.upload_file(
                path_or_fileobj=str(src),
                path_in_repo=filename,
                repo_id=REPO_ID,
                repo_type="model",
            )
            print("OK")
        except Exception as e:
            print(f"ERROR: {e}")
            errors.append(f"{filename}: {e}")

    if errors:
        print(f"\n{len(errors)} upload(s) failed:")
        for e in errors:
            print(f"  - {e}")
        sys.exit(1)
    else:
        print(f"\nAll files uploaded to https://huggingface.co/{REPO_ID}")


if __name__ == "__main__":
    main()
