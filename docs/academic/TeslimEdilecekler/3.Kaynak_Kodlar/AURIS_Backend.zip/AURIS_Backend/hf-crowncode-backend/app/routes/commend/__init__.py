"""
Crown Commend - AI-Powered YouTube Comment Generator
CrownCode platform integration for CommendAI functionality.
"""

from .router import router

__all__ = ["router"]
