"""
Crown Commend API Routes
AI-powered YouTube comment generation and posting.
"""

from __future__ import annotations

import os
import time
from collections import defaultdict
from typing import Literal, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from pydantic import BaseModel, Field, field_validator

from .youtube_service import (
    extract_video_id,
    get_video_details,
    get_channel_details,
    get_video_comments,
    get_video_transcript,
    post_youtube_comment,
    is_youtube_configured,
    is_oauth_configured
)
from .gemini_service import generate_comment
from .comment_tracker import (
    is_video_commented,
    mark_video_commented,
    get_video_comment_info,
    get_comment_stats
)
from ...services.logging_config import get_logger

logger = get_logger(__name__)
router = APIRouter(prefix="/api/commend", tags=["commend"])


# --- Pydantic Models ---

class GenerateCommentRequest(BaseModel):
    """Request model for comment generation."""
    videoUrl: str = Field(..., min_length=10, description="YouTube video URL")
    language: Literal['Turkish', 'English', 'Russian', 'Chinese', 'Japanese'] = Field(
        default='Turkish',
        description="Target language for the comment"
    )
    commentStyle: str = Field(
        default='supportive',
        description="Comment style (supportive, analytical, humorous, etc.)"
    )

    @field_validator('videoUrl')
    @classmethod
    def validate_youtube_url(cls, v: str) -> str:
        if not extract_video_id(v):
            raise ValueError('Invalid YouTube URL format')
        return v


class PostCommentRequest(BaseModel):
    """Request model for posting a comment."""
    videoUrl: str = Field(..., min_length=10)
    commentText: str = Field(..., min_length=1, max_length=10000)

    @field_validator('videoUrl')
    @classmethod
    def validate_youtube_url(cls, v: str) -> str:
        if not extract_video_id(v):
            raise ValueError('Invalid YouTube URL format')
        return v


class VideoDetailsResponse(BaseModel):
    """Response model for video details."""
    videoId: str
    title: str
    channelName: str
    channelId: str
    description: str
    thumbnailUrl: Optional[str]
    viewCount: int
    likeCount: int
    commentCount: int
    duration: int
    publishedAt: Optional[str]
    subscriberCount: Optional[int] = None


class GenerateCommentResponse(BaseModel):
    """Response model for comment generation."""
    status: str
    generatedText: str
    videoDetails: VideoDetailsResponse
    processingTime: float
    hasTranscript: bool


class PostCommentResponse(BaseModel):
    """Response model for posting a comment."""
    status: str
    message: str
    commentId: Optional[str] = None
    postedAt: Optional[str] = None
    alreadyCommented: bool = False


class CommendHealthResponse(BaseModel):
    """Health check response for Commend service."""
    status: str
    geminiConfigured: bool
    youtubeConfigured: bool
    message: str


# --- Auth & Rate Limiting ---

_COMMEND_API_KEY = os.getenv("COMMEND_API_KEY")
_COMMEND_POSTING_ENABLED = os.getenv("COMMEND_ENABLE_POSTING", "false").lower() == "true"
_COMMEND_REQUIRE_AUTH = os.getenv("COMMEND_REQUIRE_AUTH", "true").lower() != "false"

# Simple in-memory rate limiter: IP -> list of timestamps
_rate_limit_store: dict[str, list[float]] = defaultdict(list)
_RATE_LIMIT_WINDOW = 60  # seconds
_RATE_LIMIT_MAX = 10  # requests per window
_MAX_TRACKED_IPS = 10_000


def _evict_stale_ips() -> None:
    """Remove expired entries when map grows beyond threshold."""
    if len(_rate_limit_store) <= _MAX_TRACKED_IPS:
        return
    cutoff = time.time() - _RATE_LIMIT_WINDOW
    stale_keys = [ip for ip, ts in _rate_limit_store.items() if all(t <= cutoff for t in ts)]
    for key in stale_keys:
        del _rate_limit_store[key]


def _check_rate_limit(client_ip: str) -> None:
    _evict_stale_ips()
    now = time.time()
    window_start = now - _RATE_LIMIT_WINDOW
    timestamps = _rate_limit_store[client_ip]
    # Prune old entries
    _rate_limit_store[client_ip] = [t for t in timestamps if t > window_start]
    if len(_rate_limit_store[client_ip]) >= _RATE_LIMIT_MAX:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail={"code": "rate_limit_exceeded", "message": "Rate limit exceeded. Please wait before making more requests."}
        )
    _rate_limit_store[client_ip].append(now)


async def _require_api_key(
    request: Request,
    x_api_key: Optional[str] = Header(None, alias="X-API-Key"),
) -> None:
    """Validate API key. Fail-closed: if COMMEND_REQUIRE_AUTH is true (default)
    and no COMMEND_API_KEY is configured, all requests are rejected."""
    client_ip = request.client.host if request.client else "unknown"

    # Always apply rate-limit regardless of auth configuration
    _check_rate_limit(client_ip)

    if not _COMMEND_API_KEY:
        if _COMMEND_REQUIRE_AUTH:
            # Fail-closed: auth required but no key configured
            logger.error("COMMEND_API_KEY not set but auth is required. Rejecting request.")
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail={"code": "auth_not_configured", "message": "Service authentication is not configured."}
            )
        # Explicitly opted out of auth (COMMEND_REQUIRE_AUTH=false)
        return
    if x_api_key != _COMMEND_API_KEY:
        logger.warning(f"Unauthorized commend request from {client_ip}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": "unauthorized", "message": "Invalid or missing API key."}
        )


# --- API Endpoints ---

@router.get("/health", response_model=CommendHealthResponse)
async def commend_health_check():
    """Check Commend service health and configuration."""
    gemini_key = os.getenv('COMMEND_GEMINI_API_KEY')
    youtube_configured = is_youtube_configured()
    oauth_configured = is_oauth_configured()

    # Service is OK if we can at least generate comments (Gemini + YouTube read)
    is_ok = bool(gemini_key) and youtube_configured

    return CommendHealthResponse(
        status="ok" if is_ok else "degraded",
        geminiConfigured=bool(gemini_key),
        youtubeConfigured=youtube_configured,
        message=f"Crown Commend service is running. OAuth (posting): {'enabled' if oauth_configured else 'disabled'}"
    )


@router.post("/video-details", response_model=VideoDetailsResponse)
async def get_video_info(request: GenerateCommentRequest):
    """
    Fetch video details without generating a comment.
    Useful for preview before generation.
    """
    video_id = extract_video_id(request.videoUrl)

    details, error = get_video_details(request.videoUrl)
    if error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"code": "video_details_failed", "message": str(error)}
        )

    # Optionally fetch channel subscriber count
    if details.get('channelId'):
        channel_info, _ = get_channel_details(details['channelId'])
        if channel_info:
            details['subscriberCount'] = channel_info.get('subscriberCount')

    return VideoDetailsResponse(**details)


@router.post("/generate", response_model=GenerateCommentResponse, dependencies=[Depends(_require_api_key)])
async def generate_youtube_comment(request: GenerateCommentRequest):
    """
    Generate an AI-powered comment for a YouTube video.
    Optimized for minimal API calls and token usage.
    """
    start_time = time.time()
    video_id = extract_video_id(request.videoUrl)

    # 1. Fetch video details (required)
    details, error = get_video_details(request.videoUrl)
    if error:
        logger.warning(f"Video details error: {error}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"code": "video_details_failed", "message": f"Could not fetch video details: {error}"}
        )

    # 2. Skip channel stats - not critical, saves 1 API call
    # Channel name is already in video details

    # 3. Fetch only top 5 comments (reduced from 10)
    existing_comments, _ = get_video_comments(video_id, max_results=5)

    # 4. Skip transcript summarization - saves 1 Gemini API call
    # Use raw transcript snippet instead if available
    has_transcript = False
    transcript_summary = None
    transcript_text, _ = get_video_transcript(video_id)
    if transcript_text:
        has_transcript = True
        # Just take first 500 chars as context, no separate API call
        transcript_summary = transcript_text[:500]

    # 5. Generate comment (single Gemini call)
    generated_text, gen_error = generate_comment(
        video_details=details,
        comment_style=request.commentStyle,
        language=request.language,
        existing_comments=existing_comments,
        transcript_summary=transcript_summary
    )

    if gen_error:
        logger.error(f"Comment generation failed: {gen_error}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"code": "generation_failed", "message": f"Comment generation failed: {gen_error}"}
        )

    processing_time = time.time() - start_time

    return GenerateCommentResponse(
        status="success",
        generatedText=generated_text,
        videoDetails=VideoDetailsResponse(**details),
        processingTime=round(processing_time, 2),
        hasTranscript=has_transcript
    )


@router.post("/post", response_model=PostCommentResponse, dependencies=[Depends(_require_api_key)])
async def post_comment_to_youtube(request: PostCommentRequest):
    """
    Post a comment to YouTube.

    Note: This requires valid OAuth credentials with YouTube posting permissions.
    Comments include an AI disclaimer as required by platform policies.
    Each video can only receive ONE comment to prevent spam/bot detection.
    Controlled by COMMEND_ENABLE_POSTING env (default: disabled).
    """
    if not _COMMEND_POSTING_ENABLED:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"code": "posting_disabled", "message": "Comment posting is disabled. Set COMMEND_ENABLE_POSTING=true to enable."}
        )

    video_id = extract_video_id(request.videoUrl)

    # Check if already commented on this video
    if is_video_commented(video_id):
        comment_info = get_video_comment_info(video_id)
        logger.warning(f"Duplicate comment attempt for video: {video_id}")
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "code": "already_commented",
                "message": "Bu videoya zaten yorum yapılmış / Already commented on this video",
                "alreadyCommented": True,
                "previousCommentId": comment_info.get('comment_id') if comment_info else None,
                "postedAt": comment_info.get('posted_at') if comment_info else None
            }
        )

    # Post to YouTube
    result, error = post_youtube_comment(video_id, request.commentText)

    if error:
        logger.error(f"Comment posting failed: {error}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"code": "posting_failed", "message": str(error)}
        )

    # Mark video as commented (for duplicate prevention)
    video_details, _ = get_video_details(request.videoUrl)
    video_title = video_details.get('title') if video_details else None
    mark_video_commented(
        video_id=video_id,
        comment_id=result.get('commentId'),
        video_title=video_title
    )

    return PostCommentResponse(
        status="success",
        message="Comment posted successfully",
        commentId=result.get('commentId'),
        postedAt=result.get('postedAt'),
        alreadyCommented=False
    )


@router.get("/check/{video_id}")
async def check_video_comment_status(video_id: str):
    """
    Check if a video has already been commented on.
    Frontend uses this to disable the post button if already commented.
    """
    is_commented = is_video_commented(video_id)
    comment_info = get_video_comment_info(video_id) if is_commented else None

    return {
        "videoId": video_id,
        "alreadyCommented": is_commented,
        "commentInfo": comment_info
    }


@router.get("/stats")
async def get_commend_stats():
    """Get overall comment statistics."""
    stats = get_comment_stats()
    return {
        "totalComments": stats.get("total_comments", 0),
        "lastUpdated": stats.get("last_updated")
    }


@router.get("/styles")
async def get_comment_styles():
    """Get available comment styles with descriptions."""
    return {
        "styles": [
            {
                "id": "supportive",
                "name": {"tr": "Destekleyici", "en": "Supportive"},
                "description": {"tr": "Pozitif ve teşvik edici", "en": "Positive and encouraging"}
            },
            {
                "id": "analytical",
                "name": {"tr": "Analitik", "en": "Analytical"},
                "description": {"tr": "Detaylı ve düşündürücü", "en": "Detailed and thought-provoking"}
            },
            {
                "id": "humorous",
                "name": {"tr": "Esprili", "en": "Humorous"},
                "description": {"tr": "Eğlenceli ve samimi", "en": "Fun and friendly"}
            },
            {
                "id": "curious",
                "name": {"tr": "Meraklı", "en": "Curious"},
                "description": {"tr": "Soru soran ve ilgili", "en": "Questioning and engaged"}
            },
            {
                "id": "professional",
                "name": {"tr": "Profesyonel", "en": "Professional"},
                "description": {"tr": "Resmi ve saygılı", "en": "Formal and respectful"}
            }
        ],
        "languages": [
            {"code": "Turkish", "name": "Türkçe", "flag": "🇹🇷"},
            {"code": "English", "name": "English", "flag": "🇬🇧"},
            {"code": "Russian", "name": "Русский", "flag": "🇷🇺"},
            {"code": "Chinese", "name": "中文", "flag": "🇨🇳"},
            {"code": "Japanese", "name": "日本語", "flag": "🇯🇵"}
        ]
    }
