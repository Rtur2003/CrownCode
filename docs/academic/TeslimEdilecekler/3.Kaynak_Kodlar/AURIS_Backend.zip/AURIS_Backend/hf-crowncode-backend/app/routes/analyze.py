"""General analysis route for CrownCode.

Handles YouTube URLs and file uploads through a unified endpoint.
Response format matches platform/hooks/analysisTypes.ts

Pipeline:
  1. Source acquisition (YouTube download or file upload)
  2. Feature extraction (spectral, temporal, harmonic)
  3. Vocal analysis (pitch, vibrato, formant, breath)
  4. Score fusion (local features + vocals + external services)
  5. Response formatting (platform-compatible JSON)
"""

from __future__ import annotations

import asyncio
import io
import time
import uuid
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from typing import Optional, List, Dict, Any, Literal
from fastapi import (
    APIRouter, File, UploadFile, Form,
    Request, Depends, HTTPException, status,
)
from pydantic import BaseModel, Field

from ..services.youtube_analysis import YouTubeAnalysisService
from ..services.preview_model import PreviewModel
from ..services.feature_extractor import (
    extract_features,
    AudioFeatures,
)
from ..services.vocal_analyzer import (
    analyze_vocals,
    VocalFeatures,
)
from ..services.score_fusion import fuse_scores, FusionResult
from ..services.clap_detector import CLAPDetectorService
from ..services.fst_client import FSTClientService
from ..services.wav2vec2_detector import Wav2Vec2DetectorService
from ..services.inference_xai import get_xai_service
from ..services.logging_config import get_logger

router = APIRouter()
logger = get_logger(__name__)

# Rate limiter for public heavy endpoints
_analyze_rate_store: dict[str, list[float]] = defaultdict(list)
_ANALYZE_RATE_WINDOW = 60  # seconds
_ANALYZE_RATE_MAX = 20  # requests per minute per IP
_ANALYZE_MAX_IPS = 10_000


async def _analyze_rate_limit(request: Request) -> None:
    """Rate limit for analysis endpoints."""
    client_ip = request.client.host if request.client else "unknown"
    now = time.time()
    cutoff = now - _ANALYZE_RATE_WINDOW

    if len(_analyze_rate_store) > _ANALYZE_MAX_IPS:
        stale = [
            ip for ip, ts in _analyze_rate_store.items()
            if all(t <= cutoff for t in ts)
        ]
        for ip in stale:
            del _analyze_rate_store[ip]

    hits = [t for t in _analyze_rate_store[client_ip] if t > cutoff]
    if len(hits) >= _ANALYZE_RATE_MAX:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail={
                "code": "rate_limit_exceeded",
                "message": "Too many requests. Please wait.",
            }
        )
    hits.append(now)
    _analyze_rate_store[client_ip] = hits


youtube_service = YouTubeAnalysisService()
preview_model = PreviewModel()
clap_service = CLAPDetectorService()
fst_service = FSTClientService()
wav2vec2_service = Wav2Vec2DetectorService()
xai_service = get_xai_service()

# Thread pool for CPU-bound audio analysis (feature extraction + vocal)
_analysis_pool = ThreadPoolExecutor(max_workers=3)


# ============================================
# Response Models - Platform Uyumlu
# ============================================

class VocalAnalysis(BaseModel):
    """Vocal analysis results for the response."""

    hasVocals: bool = False
    vocalConfidence: float = 0.0
    vocalAiScore: float = 0.0
    pitchStabilityScore: float = 0.0
    vibratoRegularityScore: float = 0.0
    formantConsistencyScore: float = 0.0
    breathPatternScore: float = 0.0
    vocalTextureScore: float = 0.0
    pitchMeanHz: float = 0.0
    pitchStdCents: float = 0.0
    vibratoRateHz: float = 0.0
    vibratoExtentCents: float = 0.0
    indicators: List[str] = Field(default_factory=list)


class AnalysisFeatures(BaseModel):
    """Audio feature analysis results."""

    spectralRegularity: float = 0.5
    temporalPatterns: float = 0.5
    harmonicStructure: float = 0.5
    artificialIndicators: List[str] = Field(default_factory=list)


class AudioInfo(BaseModel):
    """Audio file information."""

    duration: float = 0.0
    sampleRate: int = 44100
    bitrate: int = 128
    format: str = "unknown"
    channels: int = 2


class ConfidenceBandModel(BaseModel):
    tier: str
    labelTr: str
    labelEn: str
    lowerBound: float
    upperBound: float


class ModelVoteModel(BaseModel):
    name: str
    probability: float
    vote: str


class FeatureContributionModel(BaseModel):
    name: str
    label: str
    labelEn: str
    category: str
    value: float
    zScore: float
    shapValue: float
    direction: str
    description: str


class XAIExplanation(BaseModel):
    """Rich explainable analysis payload."""

    probability: float
    threshold: float
    baseProbability: float
    confidenceBand: ConfidenceBandModel
    modelVotes: List[ModelVoteModel] = Field(default_factory=list)
    bestModel: str = "XGBoost"
    topContributions: List[FeatureContributionModel] = Field(default_factory=list)
    allFeatures: Dict[str, FeatureContributionModel] = Field(default_factory=dict)
    featureCount: int = 0


class AnalysisResult(BaseModel):
    """Platform/hooks/analysisTypes.ts uyumlu."""

    isAIGenerated: bool
    confidence: float = Field(..., ge=0.03, le=0.97)
    processingTime: float
    modelVersion: str
    decisionSource: str
    analysisMode: Literal["production", "preview"]
    source: Dict[str, Any]
    features: AnalysisFeatures
    audioInfo: AudioInfo
    vocalAnalysis: Optional[VocalAnalysis] = None
    xai: Optional[XAIExplanation] = None
    towerScores: Dict[str, float] = Field(default_factory=dict)


class AnalyzeResponse(BaseModel):
    """Response model for analysis endpoint."""

    result: Optional[AnalysisResult] = None
    warnings: List[str] = Field(default_factory=list)
    errors: List[str] = Field(default_factory=list)


@router.post(
    "/api/analyze",
    response_model=AnalyzeResponse,
    dependencies=[Depends(_analyze_rate_limit)],
)
async def analyze(
    sourceType: str = Form(...),
    url: Optional[str] = Form(None),
    file: Optional[UploadFile] = File(None)
) -> AnalyzeResponse:
    """Unified analysis endpoint."""
    request_id = str(uuid.uuid4())[:8]
    start_time = time.monotonic()
    logger.info(f"[{request_id}] Analysis: sourceType={sourceType}")

    try:
        if sourceType in ("youtube", "tiktok", "instagram", "soundcloud", "twitter"):
            if not url:
                return AnalyzeResponse(errors=["missing_url"])
            return await _analyze_youtube(request_id, url, start_time)

        elif sourceType == "file":
            if not file:
                return AnalyzeResponse(errors=["missing_file"])
            return await _analyze_file(request_id, file, start_time)

        elif sourceType in ["spotify", "apple"]:
            return AnalyzeResponse(errors=["unsupported_source"])

        else:
            return AnalyzeResponse(errors=["invalid_source_type"])

    except Exception as e:
        logger.error(f"[{request_id}] Error: {e}", exc_info=True)
        return AnalyzeResponse(errors=["internal_error"])


async def _analyze_youtube(
    request_id: str, url: str, start_time: float
) -> AnalyzeResponse:
    """Analyze YouTube URL with full pipeline."""
    try:
        yt_result = await youtube_service.analyze(url, include_raw=True)
        processing_time = round(time.monotonic() - start_time, 3)

        # If download succeeded, we have audio to analyze
        # For now, use fusion with external service results + preview features
        # TODO: When YouTube pipeline returns audio path, run full extraction

        # Use preview model for feature scores until
        # YouTube pipeline returns raw audio for local
        # extraction with full feature + vocal analysis
        preview = preview_model.analyze(yt_result.source.video_id)
        features_data = preview.get("features", {})

        decision = yt_result.summary.decision_source
        result = AnalysisResult(
            isAIGenerated=yt_result.summary.is_ai_generated,
            confidence=yt_result.summary.confidence,
            processingTime=processing_time,
            modelVersion=yt_result.summary.model_version,
            decisionSource=decision,
            analysisMode="preview" if decision == "preview" else "production",
            source={
                "kind": "youtube",
                "url": url,
                "normalizedUrl": yt_result.source.normalized_url,
                "videoId": yt_result.source.video_id,
                "startTimeSec": yt_result.source.start_time_sec
            },
            features=AnalysisFeatures(
                spectralRegularity=features_data.get(
                    "spectral_regularity", 0.5,
                ),
                temporalPatterns=features_data.get(
                    "temporal_patterns", 0.5,
                ),
                harmonicStructure=features_data.get(
                    "harmonic_structure", 0.5,
                ),
                artificialIndicators=yt_result.summary.indicators
            ),
            audioInfo=AudioInfo(
                duration=yt_result.source.duration_sec or 0.0,
                sampleRate=44100,
                bitrate=128,
                format=yt_result.source.audio_format or "unknown"
            )
        )

        return AnalyzeResponse(
            result=result,
            warnings=yt_result.warnings,
            errors=yt_result.errors,
        )

    except ValueError as e:
        logger.warning(f"[{request_id}] Invalid URL: {e}")
        return AnalyzeResponse(errors=["invalid_youtube_url"])
    except Exception as e:
        logger.error(f"[{request_id}] YouTube failed: {e}")
        return AnalyzeResponse(errors=["youtube_analysis_failed"])


async def _analyze_file(
    request_id: str,
    file: UploadFile,
    start_time: float,
) -> AnalyzeResponse:
    """
    Full audio analysis pipeline for uploaded files.

    Pipeline:
      1. Validate file
      2. Extract audio features (spectral, temporal, harmonic)
      3. Analyze vocals (pitch, vibrato, formant, breath)
      4. Fuse all scores into final result
    """
    content_type = file.content_type or ""
    if not content_type.startswith("audio/"):
        return AnalyzeResponse(errors=["invalid_file_type"])

    content = await file.read()
    file_size = len(content)

    if file_size > 30 * 1024 * 1024:
        return AnalyzeResponse(errors=["file_too_large"])

    if file_size < 1024:
        return AnalyzeResponse(errors=["file_too_small"])

    mb = file_size / 1024 / 1024
    logger.info(
        f"[{request_id}] File: {file.filename} "
        f"({mb:.2f}MB)"
    )

    warnings: List[str] = []
    loop = asyncio.get_event_loop()

    # ── Run feature extraction + vocal analysis + CLAP + wav2vec2 in parallel ──
    def _extract_features_sync():
        return extract_features(io.BytesIO(content))

    def _analyze_vocals_sync():
        return analyze_vocals(io.BytesIO(content))

    def _clap_predict_sync():
        return clap_service.predict(io.BytesIO(content))

    def _wav2vec2_predict_sync():
        return wav2vec2_service.predict(io.BytesIO(content))

    feat_future = loop.run_in_executor(_analysis_pool, _extract_features_sync)
    vocal_future = loop.run_in_executor(_analysis_pool, _analyze_vocals_sync)
    clap_future = loop.run_in_executor(_analysis_pool, _clap_predict_sync)
    wav2vec2_future = loop.run_in_executor(_analysis_pool, _wav2vec2_predict_sync)

    # Await feature extraction first (required for fusion)
    try:
        features: AudioFeatures = await feat_future
        logger.info(
            f"[{request_id}] Features: "
            f"S={features.spectral_regularity:.3f} "
            f"T={features.temporal_patterns:.3f} "
            f"H={features.harmonic_structure:.3f}"
        )
    except ValueError as e:
        logger.warning(f"[{request_id}] Feature extraction failed: {e}")
        return _fallback_analysis(
            request_id, file, content, file_size, start_time, str(e),
        )
    except Exception as e:
        logger.error(f"[{request_id}] Feature extraction error: {e}", exc_info=True)
        return _fallback_analysis(
            request_id, file, content, file_size, start_time, str(e),
        )

    # Await vocal analysis (ran in parallel)
    vocals: Optional[VocalFeatures] = None
    try:
        vocals = await vocal_future
        if vocals.has_vocals:
            logger.info(
                f"[{request_id}] Vocals: "
                f"ai={vocals.vocal_ai_score:.3f} "
                f"pitch={vocals.pitch_std_cents:.1f}c"
            )
        else:
            logger.info(f"[{request_id}] No vocals detected")
    except Exception as e:
        logger.warning(f"[{request_id}] Vocal analysis failed: {e}")
        warnings.append("vocal_analysis_unavailable")

    # Await CLAP (ran in parallel)
    clap_result = None
    try:
        clap_result = await clap_future
        if clap_result.available:
            logger.info(
                f"[{request_id}] CLAP: "
                f"ai={clap_result.is_ai}, "
                f"conf={clap_result.confidence:.3f}"
            )
        else:
            logger.info(f"[{request_id}] CLAP unavailable: {clap_result.error}")
    except Exception as e:
        logger.warning(f"[{request_id}] CLAP failed: {e}")
        warnings.append("clap_analysis_unavailable")

    # Await wav2vec2 (ran in parallel)
    wav2vec2_result = None
    try:
        wav2vec2_result = await wav2vec2_future
        if wav2vec2_result.available:
            logger.info(
                f"[{request_id}] wav2vec2: "
                f"p_ai={wav2vec2_result.p_ai:.3f}"
            )
        else:
            logger.info(f"[{request_id}] wav2vec2 unavailable: {wav2vec2_result.error}")
    except Exception as e:
        logger.warning(f"[{request_id}] wav2vec2 failed: {e}")
        warnings.append("wav2vec2_unavailable")

    # FST detection (Layer 3) — async native
    fst_result = None
    try:
        fst_result = await fst_service.predict(io.BytesIO(content))
        if fst_result.available:
            logger.info(
                f"[{request_id}] FST: "
                f"ai={fst_result.is_ai}, "
                f"conf={fst_result.confidence:.3f}, "
                f"label={fst_result.label}"
            )
        else:
            logger.info(f"[{request_id}] FST unavailable: {fst_result.error}")
    except Exception as e:
        logger.warning(f"[{request_id}] FST failed: {e}")
        warnings.append("fst_analysis_unavailable")

    # ── Step 5: Score fusion ───────────────
    fusion: FusionResult = fuse_scores(
        features, vocals,
        clap_result=clap_result,
        fst_result=fst_result,
        wav2vec2_result=wav2vec2_result,
    )

    processing_time = round(time.monotonic() - start_time, 3)
    logger.info(
        f"[{request_id}] Fusion: ai={fusion.is_ai_generated}, "
        f"confidence={fusion.confidence}, source={fusion.decision_source}"
    )

    # ── Step 5b: XAI inference (explainable) ────
    xai_payload: Optional[XAIExplanation] = None
    try:
        if xai_service.available:
            xai_result = xai_service.predict(features, vocals)
            if xai_result is not None:
                xai_dict = xai_service.to_dict(xai_result)
                # Convert dicts to pydantic models
                xai_payload = XAIExplanation(
                    probability=xai_dict["probability"],
                    threshold=xai_dict["threshold"],
                    baseProbability=xai_dict["baseProbability"],
                    confidenceBand=ConfidenceBandModel(**xai_dict["confidenceBand"]),
                    modelVotes=[ModelVoteModel(**v) for v in xai_dict["modelVotes"]],
                    bestModel=xai_dict["bestModel"],
                    topContributions=[
                        FeatureContributionModel(**c)
                        for c in xai_dict["topContributions"]
                    ],
                    allFeatures={
                        k: FeatureContributionModel(**v)
                        for k, v in xai_dict["allFeatures"].items()
                    },
                    featureCount=xai_dict["featureCount"],
                )
                logger.info(
                    f"[{request_id}] XAI: p={xai_result.probability:.3f}, "
                    f"band={xai_result.confidence_band.tier}, "
                    f"top={xai_result.top_contributions[0].name if xai_result.top_contributions else 'n/a'}"
                )
    except Exception as e:
        logger.warning(f"[{request_id}] XAI failed: {e}")
        warnings.append("xai_unavailable")

    # Build tower scores dict for UI (multi-signal breakdown)
    tower_scores: Dict[str, float] = {
        "local_features": round(
            (features.spectral_regularity + features.temporal_patterns
             + features.harmonic_structure) / 3.0, 3,
        ),
    }
    if wav2vec2_result and wav2vec2_result.available:
        tower_scores["wav2vec2"] = round(wav2vec2_result.p_ai, 3)
    if vocals and vocals.has_vocals:
        tower_scores["vocals"] = round(vocals.vocal_ai_score, 3)
    if clap_result and clap_result.available:
        tower_scores["clap"] = round(clap_result.confidence, 3)
    if fst_result and fst_result.available:
        tower_scores["fst"] = round(fst_result.confidence, 3)
    if xai_payload is not None:
        tower_scores["xai_ensemble"] = round(xai_payload.probability, 3)

    # ── Step 4: Build response ─────────────
    vocal_response = None
    if vocals and vocals.has_vocals:
        vocal_response = VocalAnalysis(
            hasVocals=True,
            vocalConfidence=round(vocals.vocal_confidence, 3),
            vocalAiScore=round(vocals.vocal_ai_score, 3),
            pitchStabilityScore=round(vocals.pitch_stability_score, 3),
            vibratoRegularityScore=round(vocals.vibrato_regularity_score, 3),
            formantConsistencyScore=round(vocals.formant_consistency_score, 3),
            breathPatternScore=round(vocals.breath_pattern_score, 3),
            vocalTextureScore=round(vocals.vocal_texture_score, 3),
            pitchMeanHz=round(vocals.pitch_mean_hz, 1),
            pitchStdCents=round(vocals.pitch_std_cents, 1),
            vibratoRateHz=round(vocals.vibrato_rate_hz, 2),
            vibratoExtentCents=round(vocals.vibrato_extent_cents, 1),
            indicators=vocals.indicators,
        )

    # Estimate bitrate from file size + duration (kbps)
    estimated_bitrate = 128
    if features.duration_sec > 0:
        estimated_bitrate = max(
            32, min(
                int((file_size * 8) / (features.duration_sec * 1000)),
                2048,
            )
        )

    # Prefer XAI verdict if available — it's the calibrated classifier
    final_is_ai = fusion.is_ai_generated
    final_confidence = fusion.confidence
    final_decision = fusion.decision_source
    if xai_payload is not None:
        final_is_ai = xai_payload.probability >= xai_payload.threshold
        final_confidence = round(max(0.03, min(0.97, xai_payload.probability)), 4)
        final_decision = f"auris_xai_{xai_payload.bestModel.lower()}"

    result = AnalysisResult(
        isAIGenerated=final_is_ai,
        confidence=final_confidence,
        processingTime=processing_time,
        modelVersion=fusion.model_version,
        decisionSource=final_decision,
        analysisMode=fusion.analysis_mode,
        source={
            "kind": "file",
            "fileName": file.filename or "unknown",
            "fileSizeBytes": file_size,
            "mimeType": content_type,
        },
        features=AnalysisFeatures(
            spectralRegularity=fusion.spectral_regularity,
            temporalPatterns=fusion.temporal_patterns,
            harmonicStructure=fusion.harmonic_structure,
            artificialIndicators=fusion.indicators,
        ),
        audioInfo=AudioInfo(
            duration=round(features.duration_sec, 2),
            sampleRate=features.sample_rate,
            bitrate=estimated_bitrate,
            format=content_type.replace("audio/", ""),
            channels=1,
        ),
        vocalAnalysis=vocal_response,
        xai=xai_payload,
        towerScores=tower_scores,
    )

    return AnalyzeResponse(result=result, warnings=warnings, errors=[])


def _fallback_analysis(
    request_id: str,
    file: UploadFile,
    content: bytes,
    file_size: int,
    start_time: float,
    reason: str,
) -> AnalyzeResponse:
    """Fallback to preview model when real analysis fails."""
    logger.warning(f"[{request_id}] Falling back to preview model: {reason}")

    fingerprint = f"file_{file.filename}_{file_size}"
    preview = preview_model.analyze(fingerprint)
    features_data = preview.get("features", {})
    processing_time = round(time.monotonic() - start_time, 3)

    result = AnalysisResult(
        isAIGenerated=preview["is_ai_generated"],
        confidence=preview["confidence"],
        processingTime=processing_time,
        modelVersion=preview["model_version"],
        decisionSource="preview",
        analysisMode="preview",
        source={
            "kind": "file",
            "fileName": file.filename or "unknown",
            "fileSizeBytes": file_size,
            "mimeType": file.content_type or "audio/unknown",
        },
        features=AnalysisFeatures(
            spectralRegularity=features_data.get(
                "spectral_regularity", 0.5,
            ),
            temporalPatterns=features_data.get(
                "temporal_patterns", 0.5,
            ),
            harmonicStructure=features_data.get(
                "harmonic_structure", 0.5,
            ),
            artificialIndicators=preview.get(
                "indicators", [],
            ),
        ),
        audioInfo=AudioInfo(
            duration=0.0,
            sampleRate=44100,
            bitrate=128,
            format=(
                file.content_type or "audio/unknown"
            ).replace("audio/", ""),
        ),
    )

    return AnalyzeResponse(
        result=result,
        warnings=["analysis_fallback_preview", f"reason: {reason}"],
        errors=[],
    )
