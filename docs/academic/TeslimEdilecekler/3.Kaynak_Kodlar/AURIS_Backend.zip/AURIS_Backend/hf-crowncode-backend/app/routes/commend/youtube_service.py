"""
YouTube API Service for Crown Commend
Handles video details, comments, and posting functionality.

Authentication Strategy:
- Read operations (video details, comments): Uses API Key (COMMEND_YOUTUBE_API_KEY)
- Write operations (post comment): Uses OAuth 2.0 (COMMEND_TOKEN_JSON)
"""

from __future__ import annotations

import os
import re
import json
from typing import Optional, Tuple, List, Dict, Any
from urllib.parse import urlparse

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
import isodate

from ...services.logging_config import get_logger

logger = get_logger(__name__)

# Cached service instances
_api_key_service = None
_oauth_service = None


def _get_api_key_service():
    """
    API Key ile YouTube API servisi oluşturur.
    Read-only işlemler için kullanılır (video detayları, yorumları okuma).
    """
    global _api_key_service

    if _api_key_service is not None:
        return _api_key_service

    api_key = os.getenv('COMMEND_YOUTUBE_API_KEY')
    if not api_key:
        # Fallback: Gemini API key'i YouTube için de kullanılabilir
        api_key = os.getenv('COMMEND_GEMINI_API_KEY')

    if not api_key:
        raise ValueError("COMMEND_YOUTUBE_API_KEY environment variable is required")

    try:
        _api_key_service = build('youtube', 'v3', developerKey=api_key)
        logger.info("YouTube API Key service initialized")
        return _api_key_service
    except Exception as e:
        logger.error(f"YouTube API Key service initialization failed: {e}")
        raise ValueError(f"YouTube API initialization failed: {e}")


def _get_oauth_service():
    """
    OAuth 2.0 ile YouTube API servisi oluşturur.
    Write işlemleri için kullanılır (yorum gönderme).
    """
    global _oauth_service

    if _oauth_service is not None:
        # Check if credentials are still valid
        return _oauth_service

    SCOPES = ['https://www.googleapis.com/auth/youtube.force-ssl']

    token_json = os.getenv('COMMEND_TOKEN_JSON')
    if not token_json:
        raise ValueError("COMMEND_TOKEN_JSON environment variable is required for posting comments")

    try:
        token_data = json.loads(token_json)
        creds = Credentials.from_authorized_user_info(token_data, SCOPES)

        # Token expire olmuşsa refresh et
        if creds.expired and creds.refresh_token:
            logger.info("Refreshing expired OAuth token")
            creds.refresh(Request())

        _oauth_service = build('youtube', 'v3', credentials=creds)
        logger.info("YouTube OAuth service initialized")
        return _oauth_service
    except json.JSONDecodeError as e:
        logger.error(f"TOKEN_JSON is not valid JSON: {e}")
        raise ValueError("YouTube OAuth token is malformed")
    except Exception as e:
        logger.error(f"OAuth service initialization failed: {e}")
        raise ValueError(f"YouTube OAuth authentication failed: {e}")


_YOUTUBE_HOSTS = frozenset({
    "youtube.com", "www.youtube.com", "m.youtube.com",
    "music.youtube.com", "youtu.be", "www.youtu.be",
})
_VIDEO_ID_RE = re.compile(r"^[a-zA-Z0-9_-]{11}$")


def extract_video_id(video_url: str) -> Optional[str]:
    """YouTube URL'sinden video ID'sini çıkarır (exact-host + 11-char ID)."""
    try:
        parsed = urlparse(video_url.strip())
    except Exception:
        return None

    host = (parsed.hostname or "").lower()
    if host not in _YOUTUBE_HOSTS:
        return None

    patterns = [
        r"(?<=v=)[^&#?]+",
        r"(?<=be/)[^&#?]+",
        r"(?<=embed/)[^&#?]+",
        r"(?<=shorts/)[^&#?]+"
    ]

    for pattern in patterns:
        match = re.search(pattern, video_url)
        if match:
            candidate = match.group(0)
            if _VIDEO_ID_RE.match(candidate):
                return candidate

    return None


def get_video_details(video_url: str) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    YouTube video detaylarını çeker.
    API Key kullanır (OAuth gerektirmez).
    Returns: (details_dict, error_message)
    """
    try:
        video_id = extract_video_id(video_url)
        if not video_id:
            return None, "Invalid YouTube URL"

        youtube = _get_api_key_service()

        request = youtube.videos().list(
            part="snippet,statistics,contentDetails",
            id=video_id
        )
        response = request.execute()

        if not response.get('items'):
            return None, "Video not found"

        item = response['items'][0]
        snippet = item['snippet']
        stats = item.get('statistics', {})
        content = item.get('contentDetails', {})

        # Duration parsing
        duration_iso = content.get('duration', 'PT0S')
        duration_seconds = isodate.parse_duration(duration_iso).total_seconds()

        details = {
            'videoId': video_id,
            'title': snippet.get('title'),
            'channelName': snippet.get('channelTitle'),
            'channelId': snippet.get('channelId'),
            'description': snippet.get('description', '')[:500],
            'thumbnailUrl': snippet.get('thumbnails', {}).get('high', {}).get('url'),
            'viewCount': int(stats.get('viewCount', 0)),
            'likeCount': int(stats.get('likeCount', 0)),
            'commentCount': int(stats.get('commentCount', 0)),
            'duration': int(duration_seconds),
            'publishedAt': snippet.get('publishedAt')
        }

        return details, None

    except ValueError as e:
        return None, str(e)
    except Exception as e:
        logger.error(f"Error fetching video details: {e}")
        return None, f"Failed to fetch video details: {str(e)}"


def get_channel_details(channel_id: str) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    Kanal istatistiklerini çeker.
    API Key kullanır.
    """
    try:
        youtube = _get_api_key_service()

        request = youtube.channels().list(
            part="statistics,snippet",
            id=channel_id
        )
        response = request.execute()

        if not response.get('items'):
            return None, "Channel not found"

        item = response['items'][0]
        stats = item.get('statistics', {})
        snippet = item.get('snippet', {})

        return {
            'subscriberCount': int(stats.get('subscriberCount', 0)),
            'videoCount': int(stats.get('videoCount', 0)),
            'channelDescription': snippet.get('description', '')[:200]
        }, None

    except Exception as e:
        logger.error(f"Error fetching channel details: {e}")
        return None, "Failed to fetch channel details"


def get_video_comments(video_id: str, max_results: int = 10) -> Tuple[List[Dict[str, str]], Optional[str]]:
    """
    Video yorumlarını çeker.
    API Key kullanır.
    """
    try:
        youtube = _get_api_key_service()

        request = youtube.commentThreads().list(
            part="snippet",
            videoId=video_id,
            maxResults=max_results,
            order="relevance"
        )
        response = request.execute()

        comments = []
        for item in response.get('items', []):
            top_comment = item['snippet']['topLevelComment']['snippet']
            comments.append({
                'author': top_comment.get('authorDisplayName'),
                'text': top_comment.get('textDisplay'),
                'likeCount': top_comment.get('likeCount', 0)
            })

        return comments, None

    except Exception as e:
        logger.error(f"Error fetching comments: {e}")
        # Yorumlar kapalı olabilir, boş liste dön
        return [], None


def get_video_transcript(video_id: str) -> Tuple[Optional[str], Optional[str]]:
    """Video transcript/altyazısını çeker."""
    try:
        from youtube_transcript_api import YouTubeTranscriptApi

        # Yeni API: doğrudan get_transcript kullan
        try:
            transcript_data = YouTubeTranscriptApi.get_transcript(video_id, languages=['tr', 'en'])
        except Exception:
            # Otomatik oluşturulan altyazıyı dene
            try:
                transcript_data = YouTubeTranscriptApi.get_transcript(video_id)
            except Exception:
                return None, "No transcript available"

        full_text = ' '.join([entry['text'] for entry in transcript_data])

        # Token limiti için kısalt
        if len(full_text) > 8000:
            full_text = full_text[:8000] + "..."

        return full_text, None

    except Exception as e:
        logger.warning(f"Transcript fetch failed: {e}")
        return None, "Transcript not available"


def post_youtube_comment(video_id: str, comment_text: str) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    YouTube'a yorum gönderir.
    OAuth 2.0 gerektirir.
    """
    try:
        youtube = _get_oauth_service()

        request_body = {
            "snippet": {
                "videoId": video_id,
                "topLevelComment": {
                    "snippet": {
                        "textOriginal": comment_text
                    }
                }
            }
        }

        response = youtube.commentThreads().insert(
            part="snippet",
            body=request_body
        ).execute()

        return {
            'commentId': response.get('id'),
            'postedAt': response.get('snippet', {}).get('topLevelComment', {}).get('snippet', {}).get('publishedAt')
        }, None

    except ValueError as e:
        # OAuth not configured
        return None, str(e)
    except Exception as e:
        logger.error(f"Error posting comment: {e}")
        error_str = str(e).lower()

        if "forbidden" in error_str or "permission" in error_str:
            return None, "Comment posting is disabled for this video"
        elif "quota" in error_str:
            return None, "API quota exceeded, please try again later"
        elif "invalid" in error_str and "token" in error_str:
            return None, "OAuth token expired or invalid"
        else:
            return None, f"Failed to post comment: {str(e)}"


def is_youtube_configured() -> bool:
    """YouTube API Key yapılandırılmış mı kontrol eder."""
    return bool(os.getenv('COMMEND_YOUTUBE_API_KEY') or os.getenv('COMMEND_GEMINI_API_KEY'))


def is_oauth_configured() -> bool:
    """OAuth (yorum gönderme) yapılandırılmış mı kontrol eder."""
    return bool(os.getenv('COMMEND_TOKEN_JSON'))
