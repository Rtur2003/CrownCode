"""AURIS training pipeline — dataset loading, feature extraction, model training."""
