"""
AURIS Full Training & Evaluation Pipeline.

Orchestrates the complete ML pipeline end-to-end:

  1. Feature extraction (49 audio features + 14 vocal features)
  2. Heuristic baseline evaluation
  3. Multi-model training with 5-fold CV
  4. Publication-quality figure generation
  5. Results summary

Usage:
    python -m app.training.run_full_pipeline

    # Or with custom paths:
    python -m app.training.run_full_pipeline \\
        --manifest data/training/manifest.csv \\
        --models-dir models \\
        --figures-dir figures
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))


def main() -> None:
    parser = argparse.ArgumentParser(description="AURIS Full Pipeline")
    parser.add_argument(
        "--manifest", default="data/training/manifest.csv",
        help="Path to training manifest CSV",
    )
    parser.add_argument(
        "--models-dir", default="models",
        help="Directory for saved models",
    )
    parser.add_argument(
        "--figures-dir", default="figures",
        help="Directory for output figures",
    )
    parser.add_argument(
        "--skip-extract", action="store_true",
        help="Skip feature extraction (use existing features.csv)",
    )
    args = parser.parse_args()

    manifest_path = Path(args.manifest)
    features_path = manifest_path.parent / "features.csv"
    models_dir = Path(args.models_dir)
    figures_dir = Path(args.figures_dir)

    total_start = time.time()

    # ── Step 1: Feature Extraction ─────────────────────────────
    if not args.skip_extract:
        print("\n" + "=" * 70)
        print("  STEP 1 / 5 — Feature Extraction")
        print("=" * 70)

        from app.training.extract_features_batch import extract_batch
        t0 = time.time()
        features_path = extract_batch(manifest_path)
        print(f"\n  Extraction time: {time.time() - t0:.1f}s")
    else:
        print("\n  [Skipping extraction — using existing features.csv]")
        if not features_path.exists():
            print(f"  ERROR: {features_path} not found!")
            sys.exit(1)

    # ── Step 2: Heuristic Baseline ─────────────────────────────
    print("\n" + "=" * 70)
    print("  STEP 2 / 5 — Heuristic Baseline Evaluation")
    print("=" * 70)

    from app.training.evaluate import evaluate_heuristic_baseline
    baseline_results = evaluate_heuristic_baseline(features_path)

    # ── Step 3: Multi-Model Training ───────────────────────────
    print("\n" + "=" * 70)
    print("  STEP 3 / 5 — Multi-Model Training (5-Fold CV)")
    print("=" * 70)

    from app.training.train_classifier import train
    train_results = train(features_path, models_dir)

    # Save combined results (training + baseline) with arrays for visualization
    combined_results = train_results["all_results"].copy()

    # Add baseline heuristic results
    if "heuristic_only" in baseline_results:
        combined_results["Heuristic (no vocals)"] = baseline_results["heuristic_only"]
    if "heuristic_vocals" in baseline_results:
        combined_results["Heuristic + Vocals"] = baseline_results["heuristic_vocals"]

    # Add metadata
    combined_results["_best_model"] = train_results["best_model"]
    combined_results["_n_samples"] = int(train_results["all_results"][
        train_results["best_model"]
    ]["y_true"].__len__())
    combined_results["_n_features"] = len(train_results["feature_cols"])
    combined_results["_n_folds"] = 5

    # Load feature importance from saved results
    results_json_path = models_dir / "training_results.json"
    if results_json_path.exists():
        with open(results_json_path, "r") as f:
            saved = json.load(f)
        if "_feature_importance" in saved:
            combined_results["_feature_importance"] = saved["_feature_importance"]

    # Save full results with arrays for visualization
    full_results_path = models_dir / "full_training_results.json"
    serializable = {}
    for key, value in combined_results.items():
        if isinstance(value, dict):
            serializable[key] = {
                k: (v.tolist() if hasattr(v, "tolist") else v)
                for k, v in value.items()
            }
        else:
            serializable[key] = value

    with open(full_results_path, "w") as f:
        json.dump(serializable, f, indent=2)

    # ── Step 4: Visualization ──────────────────────────────────
    print("\n" + "=" * 70)
    print("  STEP 4 / 5 — Publication-Quality Figures")
    print("=" * 70)

    from app.training.visualize_results import generate_all_figures
    generate_all_figures(full_results_path, features_path, figures_dir)

    # ── Step 5: Summary ────────────────────────────────────────
    print("\n" + "=" * 70)
    print("  STEP 5 / 5 — Final Summary")
    print("=" * 70)

    total_time = time.time() - total_start

    print(f"\n  Pipeline completed in {total_time:.1f}s ({total_time / 60:.1f}m)")
    print(f"\n  Best model: {train_results['best_model']}")
    print(f"  Best AUC:   {train_results['best_auc']:.4f}")
    print(f"\n  Artifacts:")
    print(f"    Model:    {train_results['model_path']}")
    print(f"    Results:  {full_results_path}")
    print(f"    Figures:  {figures_dir}/")
    print(f"    Features: {features_path}")

    # Print all model results in a table
    print(f"\n  {'Model':<25} {'Acc':>7} {'Prec':>7} {'Rec':>7} {'F1':>7} {'AUC':>7}")
    print(f"  {'─' * 25} {'─' * 7} {'─' * 7} {'─' * 7} {'─' * 7} {'─' * 7}")

    for name in sorted(train_results["all_results"].keys()):
        data = train_results["all_results"][name]
        print(
            f"  {name:<25} "
            f"{data.get('accuracy', 0):>7.4f} "
            f"{data.get('precision', 0):>7.4f} "
            f"{data.get('recall', 0):>7.4f} "
            f"{data.get('f1', 0):>7.4f} "
            f"{data.get('roc_auc', 0):>7.4f}"
        )

    print("\n" + "=" * 70)
    print("  AURIS Training Pipeline Complete!")
    print("=" * 70)


if __name__ == "__main__":
    main()
