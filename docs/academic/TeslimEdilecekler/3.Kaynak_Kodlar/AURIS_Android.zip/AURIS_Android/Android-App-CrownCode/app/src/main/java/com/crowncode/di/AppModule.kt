package com.crowncode.di

import android.app.Application
import androidx.room.Room
import com.crowncode.BuildConfig
import com.crowncode.data.local.CrownCodeDatabase
import com.crowncode.data.local.dao.AnalysisHistoryDao
import com.crowncode.data.remote.api.AnalyzeApi
import com.crowncode.data.repository.AnalysisRepositoryImpl
import com.crowncode.domain.repository.AnalysisRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideJson(): Json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        isLenient = true
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .addInterceptor(
                HttpLoggingInterceptor().apply {
                    level = if (BuildConfig.DEBUG) {
                        HttpLoggingInterceptor.Level.HEADERS
                    } else {
                        HttpLoggingInterceptor.Level.NONE
                    }
                }
            )
            .build()
    }

    @Provides
    @Singleton
    fun provideRetrofit(
        okHttpClient: OkHttpClient,
        json: Json
    ): Retrofit {
        return Retrofit.Builder()
            .baseUrl(BuildConfig.HF_API_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
    }

    @Provides
    @Singleton
    fun provideAnalyzeApi(retrofit: Retrofit): AnalyzeApi {
        return retrofit.create(AnalyzeApi::class.java)
    }

    @Provides
    @Singleton
    fun provideDatabase(app: Application): CrownCodeDatabase {
        return Room.databaseBuilder(
            app,
            CrownCodeDatabase::class.java,
            "crowncode.db"
        ).build()
    }

    @Provides
    @Singleton
    fun provideAnalysisHistoryDao(db: CrownCodeDatabase): AnalysisHistoryDao {
        return db.analysisHistoryDao()
    }

    @Provides
    @Singleton
    fun provideAnalysisRepository(api: AnalyzeApi): AnalysisRepository {
        return AnalysisRepositoryImpl(api)
    }
}
