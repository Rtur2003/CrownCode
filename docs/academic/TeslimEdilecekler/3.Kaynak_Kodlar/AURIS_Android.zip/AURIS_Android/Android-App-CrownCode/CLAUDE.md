# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

CrownCode AI - Native Android application for AI-generated music detection. Port of the web platform from `C:\Users\MONSTER\Desktop\CrownCode`.

**Important:** Source project is read-only. Copy files but never modify the original CrownCode repository.

## Build Commands

```bash
# Build debug APK
./gradlew assembleDebug

# Build release APK
./gradlew assembleRelease

# Run unit tests
./gradlew test

# Run instrumented tests
./gradlew connectedAndroidTest

# Lint checks
./gradlew lint

# Clean build
./gradlew clean
```

## Technology Stack

- **Language:** Kotlin 2.0
- **UI:** Jetpack Compose + Material 3
- **Architecture:** Clean Architecture + MVVM
- **DI:** Hilt (Dagger)
- **Async:** Coroutines & Flow
- **Network:** Retrofit + OkHttp
- **Navigation:** Compose Navigation (Type-safe)
- **Serialization:** Kotlinx Serialization

## Architecture

```
app/src/main/java/com/crowncode/
├── CrownCodeApp.kt              # Hilt Application
├── MainActivity.kt              # Single Activity
├── di/                          # Dependency Injection
│   └── AppModule.kt
├── data/                        # Data Layer
│   ├── remote/api/              # Retrofit APIs
│   ├── remote/dto/              # DTOs
│   ├── local/                   # Room/DataStore
│   └── repository/              # Repository implementations
├── domain/                      # Domain Layer
│   ├── model/                   # Domain models
│   ├── repository/              # Repository interfaces
│   └── usecase/                 # Use cases
├── presentation/                # UI Layer
│   ├── navigation/              # Navigation setup
│   ├── theme/                   # Compose theme
│   ├── components/              # Reusable components
│   └── screens/aimusic/         # AI Music Detection screen
└── util/                        # Utilities
```

## Key Conventions

1. **UI State:** Use sealed interfaces for UI states
2. **ViewModels:** Inject via Hilt, expose StateFlow
3. **Composables:** Keep stateless, hoist state up
4. **Theming:** Use MaterialTheme colors, Gold (#D4AF37) as primary

## Source Reference

Original web platform: `C:\Users\MONSTER\Desktop\CrownCode\platform`
- UI patterns from: `pages/ai-music-detection/`
- Design system from: `styles/` and `tailwind.config.js`
